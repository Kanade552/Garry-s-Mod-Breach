
FOG_SETTINGS = {
    pos1 = Vector(800,7762,1480),
    pos2 = Vector(-8096,-1274,3206)
}

POCKETDIMENSION = {
	{
        pos1 = Vector(1521,5391,467),
        pos2 = Vector(4287,3840,910)
   },
	{
        pos1 = Vector(1648,5505,-119),
        pos2 = Vector(4095,6656,897)
   }
}

print("Gamemode loaded mapconfigs/br_site19/shared.lua")