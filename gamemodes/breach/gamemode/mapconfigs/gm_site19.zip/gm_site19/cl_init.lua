include("shared.lua")

print("Gamemode loaded mapconfigs/br_site19/cl_init.lua")